require "test/unit"

require_relative "tc_song"
require_relative "tc_pattern"
